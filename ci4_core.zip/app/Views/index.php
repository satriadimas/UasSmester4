<?= $this->extend('/layouts/tempelate'); ?>

<?= $this->section('content'); ?>
<div class="container">

    <h1>Welcome!!</h1>
    <p>Silahkan mengambil antrian</p>

</div>
<?= $this->endSection(); ?>